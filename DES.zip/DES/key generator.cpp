#include<iostream>
using namespace std;

int main()
{
    int a[56];
    int i,d;
    int counter=0;
    int b[48]={14,17,11,24,1,5,3,28,15,6,21,10,23,19,12,4,26,8,16,7,27,20,13,2,41,52,31,37,47,55,30,40,51,45,33,48,44,49,39,56,34,53,46,42,50,36,29,32};

    cout<<"Enter c,d:"<<endl;

    for (i=0;i<56;i++)
        cin>>a[i];
    cout<<"Key:"<<endl;

    for (i=0;i<48;i++)
    {
        d=b[i];
        b[i]=a[d-1];
        cout<<b[i];
        counter++;
        if(counter%4==0)
            cout<<"  ";
    }
}
