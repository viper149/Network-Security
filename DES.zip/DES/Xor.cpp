#include<iostream>
using namespace std;

int a[32]={0,1,0,1,0,0,1,0,1,1,0,0,1,1,0,0,0,1,1,1,1,1,0,0,1,1,1,1,0,0,0,0};
int i,j,b[32],counter=0,counter2=0;

void Xor()
    {
        cout<<endl<<"R"<<counter2<<":"<<endl;

    for(i=0;i<32;i++)
        {
            if(a[i]==0&&b[i]==0)
                b[i]=0;
            else if(a[i]==0&&b[i]==1)
                b[i]=1;
            else if(a[i]==1&&b[i]==0)
                b[i]=1;
            else
                b[i]=0;

            cout<<b[i];
            counter++;
            if(counter%4==0)
            cout<<"  ";
        }
    }

int main()
{
    cout<<"Enter R prev:"<<endl;

    for (i=0;i<32;i++)
        cin>>b[i];
                ///XOR///

    for (j=0;j<16;i=j++)
    {
        counter2++;
        Xor();
    }
}
