#include<iostream>
using namespace std;

int a[32],i,d;;
int counter=0;
int b[32]={16,7,20,21,29,12,28,17,1,15,23,26,5,18,31,10,2,8,24,14,32,27,3,9,19,13,30,6,22,11,4,25};

void Xor()
    {
        cout<<endl<<"R:"<<endl;

    for(i=0;i<32;i++)
        {
            if(a[i]==0&&b[i]==0)
                b[i]=0;
            else if(a[i]==0&&b[i]==1)
                b[i]=1;
            else if(a[i]==1&&b[i]==0)
                b[i]=1;
            else
                b[i]=0;

            cout<<b[i];
            counter++;
            if(counter%4==0)
            cout<<"  ";
        }
    }

int main()
{
    cout<<"Enter s:"<<endl;

    for (i=0;i<32;i++)
        cin>>a[i];
    cout<<"P(S)"<<endl;

    for (i=0;i<32;i++)
    {
        d=b[i];
        b[i]=a[d-1];
        cout<<b[i];
        counter++;
        if(counter%4==0)
            cout<<"  ";
    }

    cout<<"Enter R:"<<endl;

    for (i=0;i<32;i++)
        cin>>a[i];
    Xor();
}


