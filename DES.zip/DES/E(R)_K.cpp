#include<iostream>
using namespace std;

int a[32],c[48],i,d;
int counter=0;
int b[48]={32,1,2,3,4,5,4,5,6,7,8,9,8,9,10,11,12,13,12,13,14,15,16,17,16,17,18,19,20,21,20,21,22,23,24,25,24,25,26,27,28,29,28,29,30,31,32,1};

void Xor()
    {
        cout<<endl<<"Result:"<<endl;

    for(i=0;i<48;i++)
        {
            if(c[i]==0&&b[i]==0)
                b[i]=0;
            else if(c[i]==0&&b[i]==1)
                b[i]=1;
            else if(c[i]==1&&b[i]==0)
                b[i]=1;
            else
                b[i]=0;

            cout<<b[i];
            counter++;
            if(counter%6==0)
            cout<<"  ";
        }
    }

int main()
{
    cout<<"Enter r:"<<endl;

    for (i=0;i<32;i++)
        cin>>a[i];
    cout<<"E(R):"<<endl;

    for (i=0;i<48;i++)
    {
        d=b[i];
        b[i]=a[d-1];
        cout<<b[i];
        counter++;
        if(counter%4==0)
            cout<<"  ";
    }

    cout<<endl<<
    "Enter k:"<<endl;
    for(i=0;i<48;i++)
    {
        cin>>c[i];
    }
    Xor();
}

